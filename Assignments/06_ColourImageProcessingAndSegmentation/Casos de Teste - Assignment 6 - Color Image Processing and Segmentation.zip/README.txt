Arquivo zip gerado em: 03/07/2022 12:21:07 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Assignment 6 - Color Image Processing and Segmentation