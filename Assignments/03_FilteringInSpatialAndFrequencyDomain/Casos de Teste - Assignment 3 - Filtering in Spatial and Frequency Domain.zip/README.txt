Arquivo zip gerado em: 25/04/2022 15:07:47 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Assignment 3 - Filtering in Spatial and Frequency Domain